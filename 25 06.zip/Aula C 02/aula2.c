#include <stdio.h>

int main() {
    int idade = 25;
    float altura = 1.75;
    char letra = 'A';

    printf("Idade: %d\n", idade);
    printf("Altura: %.2f\n", altura);
    printf("Letra: %c\n", letra);

    return 0;
}
