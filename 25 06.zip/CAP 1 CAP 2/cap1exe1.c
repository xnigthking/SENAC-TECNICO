#include <stdio.h>

int main() {
    printf("meu primeiro programa em C! :)\n");
    return 0;
}
