#include <stdio.h>

int main() {
    int a = 1;
    float b = 3;

    printf("a = %d , b = %f \n", a, b);

    printf("Digite o valor:");

    scanf("%d", &a);

    return 0;
}
