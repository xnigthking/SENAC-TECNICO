#include <stdio.h>

int main() {
    printf("Ana\n");
    printf("Carlos\n");
    printf("Julia\n");
    return 0;
}
