#include <stdio.h>

int main() {
    printf("maçã, banana, laranja, uva, melancia\n");
    return 0;
}
