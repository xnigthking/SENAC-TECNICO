#include <stdio.h>

int main() {
    int a = 10;  // exemplo de valor para a

    printf("a = %d\n", a);

    return 0;
}
