#include <stdio.h>

int main() {
    printf("   /\\\n");
    printf("  /  \\\n");
    printf(" /____\\\n");
    printf(" |    |\n");
    printf(" |____|\n");
    return 0;
}
