#include <stdio.h>

int main() {
    int a = 5, b2 = -2;

    printf("Valores a e b2: %d %d\n", a, b2);

    return 0;
}
