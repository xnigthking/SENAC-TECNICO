#include <stdio.h>

int main() {
    for (int i = 10; i <= 20; i++) {
        printf("%d ", i);
    }

    printf("\n"); // Para quebrar a linha no final
    return 0;
}
