#include <stdio.h>

int main () {
    printf("Meu Primeiro Programa em C");

    return 0;
}