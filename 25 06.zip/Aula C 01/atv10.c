// Entrada e saida de dados
#include<stdio.h>

int main(){
    int numero;
    printf("Digite um numero da idade do Pato Donald");
    scanf("%d", &numero);
    printf("Voce digitou: %d\n", numero);

    return 0;
}