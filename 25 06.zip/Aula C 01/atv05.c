//Operadores de Atribuicao

#include<stdio.h>

int main(){
    int x;
    x = 10;

    printf("O valor de X e: %d\n", x);

    return 0;
}