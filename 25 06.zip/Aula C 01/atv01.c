#include<stdio.h>

int main(){
    // Declaração de variaveis

    int idade;
    float valorDoPgto;
    double velParticula;
    char tipoHabMotor;

    return 0;
}