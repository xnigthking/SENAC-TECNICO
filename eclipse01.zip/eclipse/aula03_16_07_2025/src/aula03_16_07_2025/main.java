package aula03_16_07_2025;

public class main {

	public static void main(String[] args) {
		Pessoa pessoa1 = new Pessoa("Luis Eduardo", 32, 1.78,'M',"048.754.891-45");
		
		/*pessoa1.criarContaBancaria();
		
		pessoa1.apresentar();
		
		pessoa1.depositar(300.00);
		pessoa1.sacar(20.00);
		
		pessoa1.consultarSaldo();*/
		
		pessoa1.setNome("Eduardo Brandão");
		
		System.out.println(pessoa1.getNome());
		
	}

}
