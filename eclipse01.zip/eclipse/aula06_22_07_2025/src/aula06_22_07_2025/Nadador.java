package aula06_22_07_2025;

public interface Nadador {
	void nadar();
}
