package aula06_22_07_2025;

public class main {

	public static void main(String[] args) {
		Anta a1 = new Anta("Peleleu", 4, 30.0);

		a1.emitirSom();
		a1.nadar();

		Peixe p1 = new Peixe("Pirarucu", 8.0);
		p1.nadar();
	}
}
