package br.com.banco.model;

public interface Tributavel {
    double calcularTributo(); // método abstrato
}
